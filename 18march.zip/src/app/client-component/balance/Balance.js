import React from 'react'

const Balance = () => {
  return (
    <div>Balance</div>
  )
}

export default Balance